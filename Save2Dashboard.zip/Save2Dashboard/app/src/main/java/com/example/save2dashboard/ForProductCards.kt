package com.example.save2dashboard

data class ForProductCards(var productName:String, var productImage:Int, var productPrice: String)
